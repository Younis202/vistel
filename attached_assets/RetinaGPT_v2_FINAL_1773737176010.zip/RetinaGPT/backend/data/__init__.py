"""Retina-GPT Data Package."""
